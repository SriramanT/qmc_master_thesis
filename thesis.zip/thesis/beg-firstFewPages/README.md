first few pages

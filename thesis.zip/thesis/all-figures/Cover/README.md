Cover images

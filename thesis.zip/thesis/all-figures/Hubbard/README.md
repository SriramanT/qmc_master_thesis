Figures on chapter 2
